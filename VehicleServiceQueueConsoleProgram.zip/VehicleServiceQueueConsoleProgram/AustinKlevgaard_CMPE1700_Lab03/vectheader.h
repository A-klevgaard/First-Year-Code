#pragma once
//Name: Austin Klevgaard
//CMPE 1700
//Lab 03
//file: vectheader.h

//structure to hold vehicle information
typedef struct vehicle {
	int* regisNum;
	char* serviceDate[20];
	char* make[20];
	char* firstName[20];
	char* lastName[20];
	int* engineCap;

}vehicle;

//vector structure to hold an array of vehicle information
typedef struct vectVehicle{
	vehicle* vehicleInfo;
	int size;
	int capacity;

}vectVehicle;

//vector queue used to hold car data in a first in, first out fashion
typedef struct vectQueue {

	vectVehicle* items;
	int front;
	int rear;

}vectQueue;	

//Prototypes
vehicle GetCarInfo();
vectQueue* CreateQueue();
void VectorInit(vectVehicle* item);
void Enqueue(vectQueue* inQueue, vehicle inputCar);
void VectorAdd(vectVehicle* items, vehicle inputCar);
int VectorBegin(vectVehicle* v);
int VectorSize(vectVehicle* v);
void PrintQueue(vectQueue* q);
void VectorTransverse(vectVehicle* v);
vehicle VehicleGet(vectVehicle* v, int index);
void Peek(vectQueue* q);
void VectorDelete(vectVehicle* itms, int index);
void Dequeue(vectQueue* q);

//autopopulates the waiting queue with 11 data values
void SecretTestFunction(vectQueue* q);