//Name: Austin Klevgaard
//CMPE 1700
//Lab 03
//main.c
#include <stdio.h>
#include <stdlib.h>
#include "vectheader.h"
#include "stackheader.h"
#include <string.h>
#include <time.h>

int main()
{
	vectQueue* waitingQueue = CreateQueue();				//Creates the memory space for the waiting queue
	vectQueue* serviceQueue = CreateQueue();				//creates the memory space for the servicing queue
	billStack* stackBills = CreateStack();					//creates the memory space for the bill stack
	billStorage billStore = CreateVector();					//Creates memory space and initializes the paid queue vector
	
	char input[20];											//char array to hold user input
	int userSelect = -1;									//integer used to control user selection

	vehicle newCar;											//vehicle object used to import data from the user into the queue
	int cost = 0;											//randomized cost of service based on a time seed

	//Loop to control user menu selection
	while (userSelect != 0)
	{
		//sets user select back to its default  of -1
		userSelect = -1;
		printf("\n\n****************************************************");
		printf("\nPlease enter a Command: ");
		printf("\n1. Add a new vehicle to the waiting queue.");
		printf("\n2. Display the waiting queue.");
		printf("\n3. Check the next car to service.");
		printf("\n4. Transfer car from waiting queue to service queue.");
		printf("\n5. Display the service queue.");
		printf("\n6. Display the number of vehicles in each queue.");
		printf("\n7. Remove a car from the service queue, and add it's bill to the stack.");
		printf("\n8. Display all bills on the stack.");
		printf("\n9. Remove a bill from the stack, add it's cost and move it to the vector");
		printf("\n10. Display the sum of bills not yet paid.");
		printf("\n11. Display the sum of all bills paid");
		printf("\n0. Exit");

		printf("\n****************************************************");
		printf("\nUser Selection: ");


		//accepts input from the user and controls for input validity
		if (fgets(input, sizeof(input), stdin) != NULL)
		{
			if (1 == sscanf_s(input, "%d", &userSelect))
			{
				if ((userSelect > 12) || (userSelect < 0))
				{
					printf("\n\nInvalid input. Try again.\n\n");
				}
				else
				{
					//performs a function based on user input
					switch (userSelect)
					{
						//Enters a new vehicle to the waiting queue
						case 1:
							newCar = GetCarInfo();
							Enqueue(waitingQueue, newCar);
							break;
						//Prints out the waitingQueue
						case 2:
							PrintQueue(waitingQueue);
							break;
						//Shows the next vehicle to be serviced
						case 3:
							Peek(waitingQueue);
							break;
						//Moves a vehicle from waiting to service
						case 4:
							//prints of queue is empty
							if (waitingQueue->front == -1)
							{
								printf("\nQueue is empty.\n");
							}
							//otherwise move the vehicle info from waiting queue to service queue, 
							//then remove the data from the front of the waiting queue
							else
							{
								printf("\nMoved vehicle from waiting to service.\n");
								Enqueue(serviceQueue, VehicleGet(waitingQueue->items, 0));
								Dequeue(waitingQueue);
							}
							break;
						//prints out the service queue.
						case 5:
							PrintQueue(serviceQueue);
							break;
						//Display the number of Cars in each Queue
						case 6:
							printf("\nThe current size of the service Queue is: %d", VectorSize(serviceQueue->items));
							printf("\nthe current size of the waiting Queue is: %d", VectorSize(waitingQueue->items));
							break;
						//remove a car from the service queue and add it's queue to the stack
						case 7:
							if (serviceQueue->front == -1)
							{
								printf("\nService Queue is empty.\n");
							}
							else
							{
								//sets the seed for the random function
								srand(time(NULL));
								//selects a random cost for the bill (just like in real life) 
								//(rand() % (max_number + 1 - minimum_number) + minimum_number )
								cost = rand() % (1500 + 1 - 25) + 25;

								//takes a car from the front of the service queue and copies it into the stack
								AddToStack(stackBills, serviceQueue->items, cost);
								Dequeue(serviceQueue);
								printf("\nAdded new bill to the stack\n");
							}
							break;
						//prints all the bills on the stack
						case 8:
							PrintStack(stackBills);
							break;
						//Removes a chosen Bill from the stack, and adds it to the bill paid vector
						case 9:
							if (stackBills->Top == NULL)
							{
								printf("\nThe stack of bills is empty.");
							}
							else
							{
								//I decided to go with letting the user enter a registration number to determine which vehicle
								//is going to be moved off the stack, however in real applications there is surely a better way
								printf("\nPlease enter the registration number of the vehicle that was paid for: ");
								fgets(input, 20, stdin);
								userSelect = atoi(input);
								
								//adds the cost to the service bill
								billStore = MoveToBillPaid(stackBills, billStore, userSelect);
							}
							break;
						//prints the sum of unpaid bills
						case 10:
							printf("\nThe current sum of unpaid bills is: $%d", SumUnpaidBills(stackBills));
							break;
						//prints the sum of all the paid bills
						case 11:
							printf("\nThe current sum of paid bills is: $%d", SumPaid(billStore));
							break;
						//secret test function automatically populates the waiting queue with 11 data nodes
						case 12:
							SecretTestFunction(waitingQueue);
							break;

						//frees memory blocks and exits the program
						case 0:
							free(waitingQueue);
							free(serviceQueue);
							free(stackBills);
							free(billStore.billVector);
							exit(EXIT_SUCCESS);
							break;
					}

				}
			}
			//prints if input is invalid (doesn't enter a selection number)
			else
			{
				printf("\nInvalid input. Try again.");
			}
		}
	}
}