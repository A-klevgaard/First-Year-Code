#pragma once


typedef struct vehicle {
	int* regisNum;
	char* serviceDate[20];
	char* make[20];
	char* firstName[20];
	char* lastName[20];
	int* engineCap;

	int vectSize;
	int vectCapacity;


}vehicle;