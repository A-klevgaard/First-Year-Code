//Name: Austin Klevgaard
//CMPE 1700
//Lab 03
//name: stackfunctions.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stackheader.h"

//name: billStack* CreateStack()
//purpose: creates memory space for the stack
billStack* CreateStack()
{
	billStack* s = (billStack*)malloc(sizeof(billStack));
	s->Top = NULL;
	return s;
}
//name: serviceNode* CreateNode(serviceBill serviceBill)
//purpose: creates memory space and copies service bill data to a new node in the stack
//parameters:	serviceBill serviceBill - object used to hold vehicle information and service cost
serviceNode* CreateNode(serviceBill serviceBill)
{
	serviceNode* n = (serviceNode*)malloc(sizeof(serviceNode));
	n->billNode = serviceBill;
	n->next = NULL;
	return n;
}
//name: int IsEmpty(billStack* s)
//purpose: checks if the stack is empty
//parameters:	billstack* s - pointer to the stack
int IsEmpty(billStack* s)
{
	if (s->Top == NULL)
	{
		return NULL;
	}
	else
	{
		return 1;
	}
}
//name: void Push(billStack* s, serviceBill serviceBill)
//purpose: pushes information from a queue to the unpaid stack
//parameters:	billStack* s - pointer to the unpaid stack
//				serviceBill serviceBill - bill information to be added to the stack
void Push(billStack* s, serviceBill serviceBill)
{
	serviceNode* temp = CreateNode(serviceBill);
	temp->next = s->Top;
	s->Top = temp;
}
//name: void Pop(billStack* s)
//purpose: Takes data off the top of the stack
//parameters:	billStack* s - pointer to the stack
void Pop(billStack* s)
{
	serviceNode* temp = s->Top;
	s->Top = s->Top->next;
	free(temp);
}
//name: vehicle PeekStack(billStack* s) 
//purpose: looks at the data at the top of the stack
//parameters:	billStack* s - pointer to the stack
vehicle PeekStack(billStack* s) 
{
	return s->Top->billNode.vehicleData;
}

//name: void PrintStack(billStack* s)
//purpose: prints out all the dat in the stack
//parameters: billStack* s - pointer to the stack
void PrintStack(billStack* s)
{
	serviceNode* current = s->Top;	//temporary pointer used to iterate through the linked list stack
	
	//checks to see if the linked list is empty
	if (IsEmpty(s) == NULL)
	{
		printf("\nStack is empty.");
	}
	//otherwise, prints out all the data on the stack to the console.
	else
	{
		printf("\nThe current stack is:");
		while (current)
		{
			printf("\nFirst name: %s|	Last name: %s|	 Service Date: %s|	 Registration: %d|	 Make: %s|	 Engine Capacity: %d| Service Charge: $%d|",
				current->billNode.vehicleData.firstName,current->billNode.vehicleData.lastName,current->billNode.vehicleData.serviceDate,
				current->billNode.vehicleData.regisNum,current->billNode.vehicleData.make,current->billNode.vehicleData.engineCap,
				current->billNode.serviceCost);
			current = current->next;
		}
		printf("\n");			
	}
	
}
//name: void AddToStack(billStack* stackBills, vectVehicle* v, int cost)
//purpose: Adds vehicle information from the servicequeue to the stack
//parameters:	billStack* stackBills - pointer to the stack for storing unpaid bills
//				vectVehicle* v - pointer to the vector (inside serviceQueue) that holds the vehicle information to add to the stack
//				int cost - integer value of the cost for services performed
void AddToStack(billStack* stackBills, vectVehicle* v, int cost)
{
	serviceBill newBill;						//temporary serviceBill object to hold the bill data to be moved to stack
	newBill.vehicleData = VehicleGet(v, 0);		//adds vehicle data to the bill
	newBill.serviceCost = cost;					//adds the cost data to the bill

	Push(stackBills, newBill);					//pushes the newBill data onto the stack
}

//name: void InitBillVector(billStorage* v)
//purpose: intializes the paid bill storeage vector
//parameters:	billStorage* v - passed in billStorage vector to initialize
void InitBillVector(billStorage* v)
{
	v->capacity = 0;
	v->size;
}
//name: billStorage CreateVector()
//purpose: Creates a new Vector to hold paid bill data, and reserves memory space for the vector
billStorage CreateVector()
{
	billStorage newVector;
	
	newVector.billVector = (serviceBill*)malloc(sizeof(serviceBill));
	newVector.capacity = 0;
	newVector.size = 0;
	return newVector;
}

//name: billStorage MoveToBillPaid(billStack* stack, billStorage billStore, int registration)
//purpose: moves a bill from the unpaid bill stack onto the paid bill vector
//parameters:	billStack* stack - the stack that currently holds unpaid bills
//				billStorage billStore - struct object that holds the paid bill vector 
//				int registration - user entered registration number used to select which vehicle is moved to the vector
billStorage MoveToBillPaid(billStack* stack, billStorage billStore, int registration)
{

	billStack* tempStack = CreateStack();			//temporary stack used when pulling data that's not on the top
	serviceNode* current = stack->Top;				//copy of the linked list used to iterate through the stack
 
	//checks the stack to see if there are any vehicles with the given registration number to be paid
	//while (current->Top->billNode.vehicleData.regisNum != registration)
	while(current)
	{
		//if the vehicle to be paid is top on the stack, the copy the data to the vector and push it off the stack
		//if it is below the top, then iterate through the stack until you find the data

		//if the vehicle data matches the given registration, add the info to the bill paid vector and pop it off the stack
		if (current->billNode.vehicleData.regisNum == registration)
		{
			billStore = AddBillVector(billStore, current->billNode);
			Pop(stack);

			//if there are values on the tempstack then copy them back to the billstack
			if (tempStack->Top)
			{
				//iterate through the tempstack until it is empty, copying values back to billStack
				while (tempStack->Top != NULL)
				{
					Push(stack, tempStack->Top->billNode);
					Pop(tempStack);
				}
			}		
			//free data and return the billStore vector
			free(tempStack);
			return billStore;
		}
		//otherwise copy each value to the temp stack, pop it off, and iterate through the stack
		Push(tempStack, current->billNode);
		Pop(stack);
		current = stack->Top;

	}
	//if the bill is not on the stack then let the user know
	if (current->next == NULL)
	{
		printf("\nBill not on stack.");
		free(tempStack);
		return billStore;
	}
	//free data and return vector
	free(tempStack);
	return billStore;

}
//name: billStorage AddBillVector(billStorage v, serviceBill bill)
//purpose: Adds serviceBill data to the paid bill vector
//parameters:	billStorage v - object that holds the paid bill vector
//				serviceBill bill - new service bill data to add into the paid bill vector
billStorage AddBillVector(billStorage v, serviceBill bill)
{
	//if the vector capacity is 0 then set it's capacity to 10 and allocate a memory block for it
	if (v.capacity == 0)
	{
		v.capacity = 10;
		v.billVector = (serviceBill*)malloc(v.capacity * sizeof(serviceBill));
	}
	//if the vector capacity is currently filled, then double the vector capacity and reallocate more memory
	if (v.size == v.capacity)
	{
		v.capacity *= 2;
		v.billVector = (serviceBill*)realloc(v.billVector, v.size * sizeof(serviceBill));
	}
	//adds the new bill data to the current index at the end of the vector array (end of vector array index is == to its size)
	v.billVector[v.size] = bill;
	//increments the vector size by one
	v.size++;
	//return the modified vector
	return v;
}
//name: int SumUnpaidBills(billStack* s)
//purpose: provides an integer sum for all the bills currently in the unpaid stack
//parameters:	billStack* s - passed in stack to analyze
int SumUnpaidBills(billStack* s)
{
	int sumUnpaid = 0;				//total value that will be passed back to main
	
	serviceNode* current = s->Top;	//temporary serviceNode* linked list used to iterate through the stack

	//if stack is empty then return nothing
	if (current == NULL)
	{
		return 0;
	}
	//otherwise iterate through the stack adding all the serviceCost from each node to the total
	else
	{
		//loop through Linked list while it is not null
		while (current)
		{
			//adds the service bill cost to the total and increments node position
			sumUnpaid += current->billNode.serviceCost;
			current = current->next;
		}
		//returns total
		return sumUnpaid;
	}
}
//name: int SumPaid(billStorage v)
//purpose: sums the total service charge for all the bills that have been paid
//parameters:	billStorage v - object that holds the vector for all the paid bills
int SumPaid(billStorage v)
{	
	int total = 0;			//total for paid bills
	serviceBill tempBill;	//temporary serviceBill object to hold bill data from the list

	//if vector is empty then return 0
	if (v.size == 0)
	{
		return 0;
	}
	//else iterate through the linked list
	else
	{
		for (int i = 0; i < v.size; i++)
		{
			//add service cost data from each vector index to the total
			total += GetBill(v.billVector, i);	
		}
		return total;
	}
}

//name: int GetBill(serviceBill* vector, int index)
//purpose: returns service cost data from an index of a serviceBill vector
//parameters:	servieBill* vector - passed in vector list to analyze
//				int index - index of the vector to return info from
int GetBill(serviceBill* vector, int index)
{
	return vector[index].serviceCost;
}

