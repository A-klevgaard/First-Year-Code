//Name: Austin Klevgaard
//CMPE 1700
//Lab 03
//file: vectFucntions.c

#include "vectheader.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


//name: vectQueue* CreateQueue()
//purpose: Creates a new vectorQueue object
vectQueue* CreateQueue()
{
	//Allocates memory space for the queue
	vectQueue* q = (vectQueue*)malloc(sizeof(vectQueue));
	//allocates memory space for the vector within the queue
	q->items = (vectVehicle*)malloc(sizeof(vectVehicle));
	//initializes the variables within the vecotr
	VectorInit(q->items);
	//sets the front and the rear queue markers to -1 (outside of q index range)
	q->front = q->rear = -1;
	return q;
}
//name: void VectorInit(vectVehicle* item)
//purpose: initialzies passed vector variables to their starting state
//parameters:	vectVehicle* item - pointer to a vectVehicle that will be initialized
void VectorInit(vectVehicle* item)
{
	item->vehicleInfo = NULL;
	item->size = 0;
	item->capacity = 0;
}

//name: void PrintQueue(vectQueue* q)
//purpose: prints out all the current data in the vector
//parameters:	vectQueue* q - pointer to the queue that is being printed
void PrintQueue(vectQueue* q)
{
	//prints of queue is empty
	if (q->front == -1)
	{
		printf("\nQueue is empty.\n");
	}
	//else prints out all vehicle data in the queue
	else
	{
		printf("Vehicles in the current queue: ");
		VectorTransverse(q->items);
	}
}

void Peek(vectQueue* q)
{
	vehicle tempCar;

	if (q->front != -1)
	{
		tempCar = VehicleGet(q->items, 0);
		printf("\nFirst name: %s|	Last name: %s|	 Service Date: %s	|Registration: %d|	 Make: %s|	 Engine Capacity: %d|", tempCar.firstName, tempCar.lastName, tempCar.serviceDate, tempCar.regisNum, tempCar.make, tempCar.engineCap);
		return;
	}
	else
	{
		printf("\nQueue is empty.\n");
		return;
	}
}

//name: void VectorTransverse(vectVehicle* v)
//purpose: transverses through the vector to retrieve the data and prints it to console
//parameters:	vectVehicle* v - pointer to a vector that will be transversed and printed
void VectorTransverse(vectVehicle* v)
{
	vehicle tempCar;		//temporary vehicle structure used to hold passing data

	//iterates through vector positions and prints data
	for (int index = 0; index < v->size; index++)
	{
		tempCar = VehicleGet(v, index);	
		printf("\nFirst name: %s|	Last name: %s|	 Service Date: %s|	 Registration: %d|	 Make: %s|	 Engine Capacity: %d|", tempCar.firstName, tempCar.lastName, tempCar.serviceDate, tempCar.regisNum, tempCar.make, tempCar.engineCap);
	}
}

//name: vehicle VehicleGet(vectVehicle* v, int index)
//purpose: gets the vehicle information at an index point in the vector
//parameters:	vectVehicle* v - pointer to the vector the information is stored in
//				int index - index value to be searched in the vector
vehicle VehicleGet(vectVehicle* v, int index)
{
	if (index < v->size)
	{
		return v->vehicleInfo[index];
	}
}

//name: void Enqueue(vectQueue* inQueue, vehicle inputCar)
//purpose: Adds a new vector item to the queue
//parameters:	vectQueue* inQueue - pointer to the queue
//				vehicle inputCar - vehicle to be input into queue
void Enqueue(vectQueue* inQueue, vehicle inputCar)
{
	//adds the vehicle to the queue vector
	VectorAdd(inQueue->items, inputCar);

	//if this is the first item in the queue then rear = front = index of 0
	if (inQueue->rear == -1)
	{
		inQueue->front = inQueue->rear = VectorBegin(inQueue->items);
	}
	//else queue rear is assigned the value of the size of the queue.
	else
	{
		inQueue->rear = inQueue->items->size;
			//VectorSize(inQueue->items - 1);
	}
	return;
}

void Dequeue(vectQueue* q)
{
	//if q is empty then there is nothing to do
	if (q->front == -10) return;

	//otherwise delete the item at the first index of the Queue and move rear back one position
	VectorDelete(q->items, 0);
	q->rear -= 1;

	//if vector size is now 0, the queue is empty
	if (q->items->size == 0)
	{
		q->rear = -1;
		q->front = -1;
	}
}
//name: void VectorAdd(vectVehicle* items, vehicle inputCar)
//purpose: Adds a new vehicle item into the vector
//parameters:	vectVehicle* items - pointer to the passed vector
//				vehicle inputCar - input car info to be added into the vector
void VectorAdd(vectVehicle* items, vehicle inputCar)
{
	//if this is the first element being added then allocate space for 10 cars and set capacity value to 10
	if (items->capacity == 0)
	{
		items->capacity = 10;
		items->vehicleInfo = (vehicle*)malloc(10*sizeof(vehicle));
	}
	//if the current vector is full then double the capacity of the vector
	if (items->capacity == items->size)
	{
		items->capacity *= 2;
		items->vehicleInfo = (vehicle*)realloc(items->vehicleInfo, items->capacity * sizeof(vehicle));
	}
	//places the new element in the next available position
	items->vehicleInfo[items->size] = inputCar;
	items->size++;
}
void VectorDelete(vectVehicle* items, int index)
{
	int i, j = 0;	//integers used to swap vector data a space back so there are no gaps after deletion

	//temporary vector that is used to move values back in place, intialized to double the size of items.
	vehicle* tempVector = (vehicle*)malloc((items->size - 1) * 2 * sizeof(vehicle));

	//if index is out of range do nothing
	if (index >= items->size)
	{
		printf("Index out of range.\n");
		return;
	}

	//copies the elements of items vector array into tempVector, except for the first value, since that is deleted
	for (int i = 1; i < items->size; i++)
	{
		tempVector[j] = items->vehicleInfo[i];
		j++;
	}
	//frees the memory space in items
	free(items->vehicleInfo);
	//assigns the tempVector data back into the vehicle info data
	items->vehicleInfo = tempVector;
	//redistributes vector size and capacity to fit the new data
	items->size--;
	items->capacity = items->size * 2;


}

//name: int VectorBegin(vectVehicle* v)
//purpose: informs the user if the vector has been input with info or not
//parameters: vectVehicle* v - pointer to the vector being analyzed
int VectorBegin(vectVehicle* v)
{
	if (v->size > 0)
	{
		return 0;
	}
	else
	{
		return -1;
	}
}

//name: int VectorSize(vectVehicle* v)
//purpose: returns the size of the vector
//parameters: vectVehicle* v - pointer to the vector being analyzed
int VectorSize(vectVehicle* v)
{
	return v->size;
}

//name: vehicle GetCarInfo()
//purpose: Inputs new vehicle info from the user
vehicle GetCarInfo()
{
	char dataIn[20];					//string to hold user inputs
	char goodCheck[2] = { 'n' };		//string to hold user verification that data is correct
	vehicle InputCar;					//temp vehicle struct used to hold input car data

	while (goodCheck[0] != 'y')
	{
		//Gets first name for the new vehicle from the user
		printf("\nEnter the clients first name: ");
		fgets(dataIn, 20, stdin);
		dataIn[strlen(dataIn) - 1] = '\0';
		strcpy_s(InputCar.firstName, 20, dataIn);

		//gets last name data for the new vehicle from the user
		printf("\nEnter the clients last name: ");
		fgets(dataIn, 20, stdin);
		dataIn[strlen(dataIn) - 1] = '\0';
		strcpy_s(InputCar.lastName, 20, dataIn);

		//gets the make data from the user
		printf("\nEnter the make of the vehicle ");
		fgets(dataIn, 20, stdin);
		dataIn[strlen(dataIn) - 1] = '\0';
		strcpy_s(InputCar.make, 20, dataIn);

		//Enters the service Data
		printf("\nEnter the Service Date: ");
		fgets(dataIn, 20, stdin);
		dataIn[strlen(dataIn) - 1] = '\0';
		strcpy_s(InputCar.serviceDate, 20, dataIn);

		//Gets the Registration info for the new vehicle
		printf("\nEnter the registration number of the vehicle: ");
		fgets(dataIn, 20, stdin);
		InputCar.regisNum = atoi(dataIn);

		//gets the engine size
		printf("\nEnter the size of the engine in litres: ");
		fgets(dataIn, 20, stdin);
		InputCar.engineCap = atoi(dataIn);

		//quality check by user
		printf("\nIs this the correct Information? (y/n): ");
		if (fgets(goodCheck, sizeof(goodCheck), stdin) != NULL);

		//need an additional fgets function to reset dataIN, otherwise the reg number input is skipped on the next loop for some reason
		fgets(dataIn, sizeof(dataIn), stdin);	
	}
	return InputCar;
}
//Test function that generates a waiting queue with 11 pieces of data
void SecretTestFunction(vectQueue* q)
{
	vehicle car;


	char fNames[11][20] = { "Tom", "Bobby","Jones", "Jacob", "Akash", "Susan", "Betty", "Joanne", "Larry", "Curly", "Moe" };
	char lNames[11][20] = { "Taggert","Bimpsey","Johanus","Jackel", "Aorbal", "Snucks", "Boop", "Juicy", "Longinus", "Cordoal", "Manfred" };
	char make[11][20] = { "Ford","Toytota","Chevrolet", "Dodge","Kia","Ford","Toytota","Chevrolet", "Dodge","Kia", "Lambo" };
	char serviceDate[11][20] = { "Monday","Tuesday","Wed","Thursay","Friday","Monday","Tuesday","Wed","Thursay","Friday","Sat" };
	int registration[11] = { 1,2,3,4,5,6,7,8,9,10,11 };
	int engineCapacity[11] = { 2, 4, 6, 8, 10, 2, 4, 6, 8, 13 };

	for (int i = 0; i < 11; i++)
	{
		strcpy_s(car.firstName, 20, fNames[i]);
		strcpy_s(car.lastName, 20, lNames[i]);
		strcpy_s(car.make, 20, make[i]);
		strcpy_s(car.serviceDate, 20, serviceDate[i]);
		car.regisNum = registration[i];
		car.engineCap = engineCapacity[i];

		Enqueue(q, car);

		printf("\nThe capacity of the vector is: %d", q->items->capacity);
		printf("\nThe size of the vector is: %d", q->items->size);
	}
}