//Name: Austin Klevgaard
//CMPE 1700
//Lab 03
//name: stackheader.h
#pragma once
#include "vectheader.h"

//serviceBill defines the bill for the customer that includes their car data and the cost of service
typedef struct serviceBill {
	vehicle vehicleData;
	int serviceCost;
	struct serviceBill* next;
}serviceBill;

//serviceNode defines the linked list node, which includes the bill and the poitner to the next node
typedef struct serviceNode {
	serviceBill billNode;
	serviceBill* next;

}serviceNode;

//billstack is the location of the top of the stack (start of the linked list)
typedef struct billStack {
	serviceNode* Top;
}billStack;

//billStorage is a vector to store information for all the bills that have already been paid
typedef struct billStorage {
	serviceBill* billVector;
	int size;
	int capacity;
}billStorage;

//Prototypes
billStorage AddBillVector(billStorage v, serviceBill bill);
billStack* CreateStack();
serviceNode* CreateNode(serviceBill serviceBill);
int IsEmpty(billStack* s);
void Push(billStack* s, serviceBill serviceBill);
void Pop(billStack* s);
vehicle PeekStack(billStack* s);
void PrintStack(billStack* s);
void AddToStack(billStack* stackBills, vectVehicle* v, int cost);
void InitBillVector(billStorage* v);
billStorage CreateVector();
billStorage MoveToBillPaid(billStack* stack, billStorage billStore, int registration);
int SumUnpaidBills(billStack* s);
int SumPaid(billStorage vec);
int GetBill(serviceBill* v, int index);
	