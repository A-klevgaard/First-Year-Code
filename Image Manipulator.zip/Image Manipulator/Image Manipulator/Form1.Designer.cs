﻿namespace Lab02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Modif_type_GrpBox = new System.Windows.Forms.GroupBox();
            this.Contrast_RadioBtn = new System.Windows.Forms.RadioButton();
            this.Tint_RadioBtn = new System.Windows.Forms.RadioButton();
            this.BlackWhite_RadioBtn = new System.Windows.Forms.RadioButton();
            this.Noise_RadioBtn = new System.Windows.Forms.RadioButton();
            this.LoadPicture_Btn = new System.Windows.Forms.Button();
            this.Trackbar_Effect = new System.Windows.Forms.TrackBar();
            this.Transfrom_Btn = new System.Windows.Forms.Button();
            this.Left_Label = new System.Windows.Forms.Label();
            this.Right_Label = new System.Windows.Forms.Label();
            this.Middle_Label = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Modif_type_GrpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Trackbar_Effect)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1113, 379);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Modif_type_GrpBox
            // 
            this.Modif_type_GrpBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Modif_type_GrpBox.Controls.Add(this.Contrast_RadioBtn);
            this.Modif_type_GrpBox.Controls.Add(this.Tint_RadioBtn);
            this.Modif_type_GrpBox.Controls.Add(this.BlackWhite_RadioBtn);
            this.Modif_type_GrpBox.Controls.Add(this.Noise_RadioBtn);
            this.Modif_type_GrpBox.Location = new System.Drawing.Point(123, 423);
            this.Modif_type_GrpBox.Margin = new System.Windows.Forms.Padding(4);
            this.Modif_type_GrpBox.Name = "Modif_type_GrpBox";
            this.Modif_type_GrpBox.Padding = new System.Windows.Forms.Padding(4);
            this.Modif_type_GrpBox.Size = new System.Drawing.Size(252, 86);
            this.Modif_type_GrpBox.TabIndex = 1;
            this.Modif_type_GrpBox.TabStop = false;
            this.Modif_type_GrpBox.Text = "Modification Type";
            // 
            // Contrast_RadioBtn
            // 
            this.Contrast_RadioBtn.AutoSize = true;
            this.Contrast_RadioBtn.Checked = true;
            this.Contrast_RadioBtn.Location = new System.Drawing.Point(8, 23);
            this.Contrast_RadioBtn.Margin = new System.Windows.Forms.Padding(4);
            this.Contrast_RadioBtn.Name = "Contrast_RadioBtn";
            this.Contrast_RadioBtn.Size = new System.Drawing.Size(82, 21);
            this.Contrast_RadioBtn.TabIndex = 2;
            this.Contrast_RadioBtn.TabStop = true;
            this.Contrast_RadioBtn.Text = "Contrast";
            this.Contrast_RadioBtn.UseVisualStyleBackColor = true;
            this.Contrast_RadioBtn.CheckedChanged += new System.EventHandler(this.Contrast_RadioBtn_CheckedChanged);
            // 
            // Tint_RadioBtn
            // 
            this.Tint_RadioBtn.AutoSize = true;
            this.Tint_RadioBtn.Location = new System.Drawing.Point(129, 25);
            this.Tint_RadioBtn.Margin = new System.Windows.Forms.Padding(4);
            this.Tint_RadioBtn.Name = "Tint_RadioBtn";
            this.Tint_RadioBtn.Size = new System.Drawing.Size(53, 21);
            this.Tint_RadioBtn.TabIndex = 3;
            this.Tint_RadioBtn.Text = "Tint";
            this.Tint_RadioBtn.UseVisualStyleBackColor = true;
            this.Tint_RadioBtn.CheckedChanged += new System.EventHandler(this.Tint_RadioBtn_CheckedChanged);
            // 
            // BlackWhite_RadioBtn
            // 
            this.BlackWhite_RadioBtn.AutoSize = true;
            this.BlackWhite_RadioBtn.Location = new System.Drawing.Point(8, 58);
            this.BlackWhite_RadioBtn.Margin = new System.Windows.Forms.Padding(4);
            this.BlackWhite_RadioBtn.Name = "BlackWhite_RadioBtn";
            this.BlackWhite_RadioBtn.Size = new System.Drawing.Size(103, 21);
            this.BlackWhite_RadioBtn.TabIndex = 4;
            this.BlackWhite_RadioBtn.Text = "Black/White";
            this.BlackWhite_RadioBtn.UseVisualStyleBackColor = true;
            this.BlackWhite_RadioBtn.CheckedChanged += new System.EventHandler(this.BlackWhite_RadioBtn_CheckedChanged);
            // 
            // Noise_RadioBtn
            // 
            this.Noise_RadioBtn.AutoSize = true;
            this.Noise_RadioBtn.Location = new System.Drawing.Point(131, 58);
            this.Noise_RadioBtn.Margin = new System.Windows.Forms.Padding(4);
            this.Noise_RadioBtn.Name = "Noise_RadioBtn";
            this.Noise_RadioBtn.Size = new System.Drawing.Size(65, 21);
            this.Noise_RadioBtn.TabIndex = 5;
            this.Noise_RadioBtn.Text = "Noise";
            this.Noise_RadioBtn.UseVisualStyleBackColor = true;
            this.Noise_RadioBtn.CheckedChanged += new System.EventHandler(this.Noise_RadioBtn_CheckedChanged);
            // 
            // LoadPicture_Btn
            // 
            this.LoadPicture_Btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LoadPicture_Btn.Location = new System.Drawing.Point(15, 423);
            this.LoadPicture_Btn.Margin = new System.Windows.Forms.Padding(4);
            this.LoadPicture_Btn.Name = "LoadPicture_Btn";
            this.LoadPicture_Btn.Size = new System.Drawing.Size(100, 28);
            this.LoadPicture_Btn.TabIndex = 0;
            this.LoadPicture_Btn.Text = "Load Picture";
            this.LoadPicture_Btn.UseVisualStyleBackColor = true;
            this.LoadPicture_Btn.Click += new System.EventHandler(this.LoadPicture_Btn_Click);
            // 
            // Trackbar_Effect
            // 
            this.Trackbar_Effect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Trackbar_Effect.Location = new System.Drawing.Point(403, 423);
            this.Trackbar_Effect.Margin = new System.Windows.Forms.Padding(4);
            this.Trackbar_Effect.Maximum = 100;
            this.Trackbar_Effect.Name = "Trackbar_Effect";
            this.Trackbar_Effect.Size = new System.Drawing.Size(539, 56);
            this.Trackbar_Effect.TabIndex = 6;
            this.Trackbar_Effect.TickFrequency = 5;
            this.Trackbar_Effect.Value = 50;
            this.Trackbar_Effect.Scroll += new System.EventHandler(this.Trackbar_Effect_Scroll);
            // 
            // Transfrom_Btn
            // 
            this.Transfrom_Btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Transfrom_Btn.Enabled = false;
            this.Transfrom_Btn.Location = new System.Drawing.Point(949, 423);
            this.Transfrom_Btn.Margin = new System.Windows.Forms.Padding(4);
            this.Transfrom_Btn.Name = "Transfrom_Btn";
            this.Transfrom_Btn.Size = new System.Drawing.Size(100, 28);
            this.Transfrom_Btn.TabIndex = 7;
            this.Transfrom_Btn.Text = "Transform";
            this.Transfrom_Btn.UseVisualStyleBackColor = true;
            this.Transfrom_Btn.Click += new System.EventHandler(this.Transfrom_Btn_Click);
            // 
            // Left_Label
            // 
            this.Left_Label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Left_Label.AutoSize = true;
            this.Left_Label.Location = new System.Drawing.Point(399, 481);
            this.Left_Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Left_Label.Name = "Left_Label";
            this.Left_Label.Size = new System.Drawing.Size(38, 17);
            this.Left_Label.TabIndex = 8;
            this.Left_Label.Text = "Less";
            // 
            // Right_Label
            // 
            this.Right_Label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Right_Label.AutoSize = true;
            this.Right_Label.Location = new System.Drawing.Point(895, 481);
            this.Right_Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Right_Label.Name = "Right_Label";
            this.Right_Label.Size = new System.Drawing.Size(40, 17);
            this.Right_Label.TabIndex = 9;
            this.Right_Label.Text = "More";
            // 
            // Middle_Label
            // 
            this.Middle_Label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Middle_Label.AutoSize = true;
            this.Middle_Label.Location = new System.Drawing.Point(661, 481);
            this.Middle_Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Middle_Label.Name = "Middle_Label";
            this.Middle_Label.Size = new System.Drawing.Size(24, 17);
            this.Middle_Label.TabIndex = 10;
            this.Middle_Label.Text = "50";
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(15, 401);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(1114, 15);
            this.progressBar1.TabIndex = 11;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "BMP files|*.bmp|JPEG Files|*.jpg|PNG files|*.png|All files| *.*";
            this.openFileDialog1.RestoreDirectory = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 515);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.Middle_Label);
            this.Controls.Add(this.Right_Label);
            this.Controls.Add(this.Left_Label);
            this.Controls.Add(this.Transfrom_Btn);
            this.Controls.Add(this.Trackbar_Effect);
            this.Controls.Add(this.LoadPicture_Btn);
            this.Controls.Add(this.Modif_type_GrpBox);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Modif_type_GrpBox.ResumeLayout(false);
            this.Modif_type_GrpBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Trackbar_Effect)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox Modif_type_GrpBox;
        private System.Windows.Forms.RadioButton Contrast_RadioBtn;
        private System.Windows.Forms.RadioButton Tint_RadioBtn;
        private System.Windows.Forms.RadioButton BlackWhite_RadioBtn;
        private System.Windows.Forms.RadioButton Noise_RadioBtn;
        private System.Windows.Forms.Button LoadPicture_Btn;
        private System.Windows.Forms.TrackBar Trackbar_Effect;
        private System.Windows.Forms.Button Transfrom_Btn;
        private System.Windows.Forms.Label Left_Label;
        private System.Windows.Forms.Label Right_Label;
        private System.Windows.Forms.Label Middle_Label;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

