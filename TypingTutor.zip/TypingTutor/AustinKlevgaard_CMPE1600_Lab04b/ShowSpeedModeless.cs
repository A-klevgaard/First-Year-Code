﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Modeless form is used to control animation speed in the game
namespace AustinKlevgaard_CMPE1600_Lab04b
{
    public delegate void delVoidVoid();         //delegate to close the form
    public delegate void delVoidInt(int i);     //delegate to pass on speed data

    public partial class ShowSpeedModeless : Form
    {
        public delVoidVoid _formClosing = null;         //delegate objets from above
        public delVoidInt _chooseAnimationSpeed = null;

        public ShowSpeedModeless()
        {
            InitializeComponent();
        }

        //disregard this trackbar scroll it is not the one that wors
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (null != _chooseAnimationSpeed)
            {
                _chooseAnimationSpeed.Invoke(trackBar1.Value);
            }
        }
        //handles form closing events for the modless form from when the animation speed checkbox is unchecked in main
        private void ShowSpeedModeless_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if user closes the form after it has been created already then just hide the form
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (null == _formClosing)
                {
                    _formClosing();
                }
                e.Cancel = true;
                Hide();
            }
        }

        private void ShowSpeedModeless_Load(object sender, EventArgs e)
        {

        }
        //registers an int value that will be passed back to main from the trackbar
        private void trackBar1_Scroll_1(object sender, EventArgs e)
        {
            if (null != _chooseAnimationSpeed)
            {
                _chooseAnimationSpeed.Invoke(trackBar1.Value);
            }
        }
    }
}
