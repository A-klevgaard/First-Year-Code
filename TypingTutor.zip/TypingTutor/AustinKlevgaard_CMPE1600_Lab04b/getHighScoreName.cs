﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AustinKlevgaard_CMPE1600_Lab04b
{
    public partial class getHighScoreName : Form
    {
        string nameText;            //name data from the text box

        //public variable used to send textbox data back to main
        public string pNameText
        {
            get
            {
                return (nameText);
            }
        }

        public getHighScoreName()
        {
            InitializeComponent();
        }

        //this is a fake OKbutton, disregard this please, but removing it breaks the program
        private void OKButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void getHighScoreName_Load(object sender, EventArgs e)
        {

        }

        //cancels the modal dialogue and name is not entered
        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        //lets the user enter a name string that will be passed back to the main form
        private void nameInputTextBox_TextChanged(object sender, EventArgs e)
        {
            nameText = nameInputTextBox.Text;
        }
        //sends the data to the main form and exits from the modal form
        private void OKButton_Click_1(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void OKButton_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

        }
    }
}
