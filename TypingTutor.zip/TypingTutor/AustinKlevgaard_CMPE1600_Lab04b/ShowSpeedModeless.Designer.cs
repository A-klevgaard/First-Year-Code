﻿namespace AustinKlevgaard_CMPE1600_Lab04b
{
    partial class ShowSpeedModeless
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fastLabel = new System.Windows.Forms.Label();
            this.slowLabel = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // fastLabel
            // 
            this.fastLabel.AutoSize = true;
            this.fastLabel.Location = new System.Drawing.Point(428, 79);
            this.fastLabel.Name = "fastLabel";
            this.fastLabel.Size = new System.Drawing.Size(35, 17);
            this.fastLabel.TabIndex = 6;
            this.fastLabel.Text = "Fast";
            this.fastLabel.UseWaitCursor = true;
            // 
            // slowLabel
            // 
            this.slowLabel.AutoSize = true;
            this.slowLabel.Location = new System.Drawing.Point(9, 79);
            this.slowLabel.Name = "slowLabel";
            this.slowLabel.Size = new System.Drawing.Size(37, 17);
            this.slowLabel.TabIndex = 5;
            this.slowLabel.Text = "Slow";
            this.slowLabel.UseWaitCursor = true;
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(12, 20);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Minimum = 10;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(451, 56);
            this.trackBar1.TabIndex = 7;
            this.trackBar1.TickFrequency = 10;
            this.trackBar1.Value = 50;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll_1);
            // 
            // ShowSpeedModeless
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 127);
            this.ControlBox = false;
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.fastLabel);
            this.Controls.Add(this.slowLabel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ShowSpeedModeless";
            this.Text = "ShowSpeedModeless";
            this.Load += new System.EventHandler(this.ShowSpeedModeless_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fastLabel;
        private System.Windows.Forms.Label slowLabel;
        private System.Windows.Forms.TrackBar trackBar1;
    }
}