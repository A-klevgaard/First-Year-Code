﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AustinKlevgaard_CMPE1600_Lab04b
{
    public partial class NewGameModal : Form
    {
        int playerChoice;       //integer number to represent player difficulty choice (1-3)

        //public int used to pass data back to main form
        public int pDifficulty
        {
            get
            {
                //sends difficulty choice to main
                return (playerChoice);
            }
            //remembers difficulty choice the player last chose
            set
            {
                playerChoice = value;
            }
        }

        public NewGameModal()
        {
            InitializeComponent();
        }
        //Loads the form and checks one of the radio buttons
        private void NewGameModal_Load(object sender, EventArgs e)
        {
            if (playerChoice == 3)
            {
                hardRadioButton.Checked = true;
            }
            else if (playerChoice == 2)
            {
                mediumRadioButton.Checked = true;
            }
            else
            {
                easyRadioButton.Checked = true;
            }
        }
        //changes difficulty to easy
        private void easyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            playerChoice = 1;
        }
        //changes difficulty to easy medium
        private void mediumRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            playerChoice = 2;
        }
        //changes difficulty to easy hard
        private void hardRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            playerChoice = 3;
        }
        //passes data to main
        private void okButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
        //cancels modeless form
        private void CancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void difficultylevelGroupbox_Enter(object sender, EventArgs e)
        {

        }
    }
}
