﻿namespace AustinKlevgaard_CMPE1600_Lab04b
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EndGameButton = new System.Windows.Forms.Button();
            this.StartGameButton = new System.Windows.Forms.Button();
            this.PauseButton = new System.Windows.Forms.Button();
            this.ShowSpeedDialogueChkBox = new System.Windows.Forms.CheckBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.playerNameHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.levelHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.scoreHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CurrentScoreLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EndGameButton
            // 
            this.EndGameButton.Location = new System.Drawing.Point(12, 129);
            this.EndGameButton.Name = "EndGameButton";
            this.EndGameButton.Size = new System.Drawing.Size(100, 34);
            this.EndGameButton.TabIndex = 2;
            this.EndGameButton.Text = "End Game";
            this.EndGameButton.UseVisualStyleBackColor = true;
            this.EndGameButton.Click += new System.EventHandler(this.EndGameButton_Click);
            // 
            // StartGameButton
            // 
            this.StartGameButton.Location = new System.Drawing.Point(12, 25);
            this.StartGameButton.Name = "StartGameButton";
            this.StartGameButton.Size = new System.Drawing.Size(100, 34);
            this.StartGameButton.TabIndex = 3;
            this.StartGameButton.Text = "Start Game";
            this.StartGameButton.UseVisualStyleBackColor = true;
            this.StartGameButton.Click += new System.EventHandler(this.StartGameButton_Click);
            // 
            // PauseButton
            // 
            this.PauseButton.Location = new System.Drawing.Point(12, 78);
            this.PauseButton.Name = "PauseButton";
            this.PauseButton.Size = new System.Drawing.Size(100, 34);
            this.PauseButton.TabIndex = 4;
            this.PauseButton.Text = "Pause";
            this.PauseButton.UseVisualStyleBackColor = true;
            this.PauseButton.Click += new System.EventHandler(this.PauseButton_Click);
            // 
            // ShowSpeedDialogueChkBox
            // 
            this.ShowSpeedDialogueChkBox.AutoSize = true;
            this.ShowSpeedDialogueChkBox.Location = new System.Drawing.Point(12, 196);
            this.ShowSpeedDialogueChkBox.Name = "ShowSpeedDialogueChkBox";
            this.ShowSpeedDialogueChkBox.Size = new System.Drawing.Size(161, 21);
            this.ShowSpeedDialogueChkBox.TabIndex = 5;
            this.ShowSpeedDialogueChkBox.Text = "ShowSpeedDialogue";
            this.ShowSpeedDialogueChkBox.UseVisualStyleBackColor = true;
            this.ShowSpeedDialogueChkBox.CheckedChanged += new System.EventHandler(this.ShowSpeedDialogueChkBox_CheckedChanged);
            this.ShowSpeedDialogueChkBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ShowSpeedDialogueChkBox_KeyPress);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.playerNameHeader,
            this.levelHeader,
            this.scoreHeader});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(228, 25);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(272, 267);
            this.listView1.TabIndex = 6;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // playerNameHeader
            // 
            this.playerNameHeader.Text = "Player Name";
            this.playerNameHeader.Width = 80;
            // 
            // levelHeader
            // 
            this.levelHeader.Text = "Level";
            // 
            // scoreHeader
            // 
            this.scoreHeader.Text = "Score";
            // 
            // CurrentScoreLabel
            // 
            this.CurrentScoreLabel.AutoSize = true;
            this.CurrentScoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentScoreLabel.Location = new System.Drawing.Point(79, 311);
            this.CurrentScoreLabel.Name = "CurrentScoreLabel";
            this.CurrentScoreLabel.Size = new System.Drawing.Size(109, 38);
            this.CurrentScoreLabel.TabIndex = 7;
            this.CurrentScoreLabel.Text = "label1";
            this.CurrentScoreLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Current Score:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 409);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CurrentScoreLabel);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.ShowSpeedDialogueChkBox);
            this.Controls.Add(this.PauseButton);
            this.Controls.Add(this.StartGameButton);
            this.Controls.Add(this.EndGameButton);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Typing Tutor - Austin Klevgaard";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button EndGameButton;
        private System.Windows.Forms.Button StartGameButton;
        private System.Windows.Forms.Button PauseButton;
        private System.Windows.Forms.CheckBox ShowSpeedDialogueChkBox;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label CurrentScoreLabel;
        private System.Windows.Forms.ColumnHeader playerNameHeader;
        private System.Windows.Forms.ColumnHeader levelHeader;
        private System.Windows.Forms.ColumnHeader scoreHeader;
        private System.Windows.Forms.Label label1;
    }
}

